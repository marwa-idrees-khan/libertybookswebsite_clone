
  document.addEventListener("DOMContentLoaded", () => {
    const input = document.getElementById("searchInput");
    const errorMsg = document.getElementById("errorMsg");
    const regex = /^[A-Za-z\s]*$/;

    input.addEventListener("input", () => {
      if (!regex.test(input.value)) {
        errorMsg.classList.remove("hidden");
      } else {
        errorMsg.classList.add("hidden");
      }
    });
  });

